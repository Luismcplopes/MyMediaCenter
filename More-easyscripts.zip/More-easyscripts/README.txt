https://discourse.osmc.tv/t/how-to-install-couchpotato-and-sickrage-on-raspberry-pi/10788
Put scripts in folder /home/osmc/ or /home/osmc/scripts/
Otherwise may not work correctly.

Run as sudo, example:
sudo sh easyinstallv2.sh

Enjoy!


p.s.
more instructions can be found here:
https://discourse.osmc.tv/t/how-to-install-couchpotato-and-sickrage/10788/

https://www.digitalocean.com/community/tutorials/how-to-use-systemctl-to-manage-systemd-services-and-units