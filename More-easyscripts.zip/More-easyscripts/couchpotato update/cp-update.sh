#!/bin/bash
# CuchPotato Auto Update Script from htpcBeginner
sudo service couchpotato stop
sleep 10
#foldee where is installed couchpotato
sudo mv /opt/CouchPotatoServer /opt/CouchPotatoServer.old
cd /opt/
sudo git clone https://github.com/RuudBurger/CouchPotatoServer.git /opt/CouchPotatoServer
sudo service couchpotato start
