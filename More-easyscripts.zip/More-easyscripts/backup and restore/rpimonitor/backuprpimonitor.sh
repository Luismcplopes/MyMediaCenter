#!bash.sh
#create backup files of rpi monitor
echo "creating settings backup of rpimonitor"
sudo mkdir /home/osmc/backup/
sudo cp -R /etc/rpimonitor /home/osmc/backup/rpimonitor
echo "backup successfully created in folder rpimonitor"
