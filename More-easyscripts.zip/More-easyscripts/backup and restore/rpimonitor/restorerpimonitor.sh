#!bash.sh
#create backup files of rpi monitor
sudo service rpimonitor stop
echo "restoring settings of rpimonitor"
sudo cp -R /home/osmc/backup/rpimonitor /etc/rpimonitor
sudo service rpimonitor start
echo "backup successfully restored in folder rpimonitor"
