#!/bin/sh
#backup database and settings for couchpotato, sickrage and transmission
echo "restore in progress..."
echo "stopping services..."
sudo service couchpotato stop
sudo service sickrage stop
sudo service transmission stop
cd /home/osmc/
echo "starting restoring files..."
sudo cp /home/osmc/backup/settings/sickrage/*.* /opt/sickrage/
sudo chmod 775 -R /opt/sickrage
sudo chown sickrage:sickrage -R /opt/sickrage
sudo cp /home/osmc/backup/settings/couchpotato/*.* /home/couchpotato/.couchpotato/
sudo chmod 775 -R /home/couchpotato/.couchpotato
sudo chown couchpotato:couchpotato -R /home/couchpotato/.couchpotato
sudo cp /home/osmc/backup/settings/transmission/*.* /home/osmc/.config/transmission-daemon/
sudo chmod 775 -R /home/osmc/.config/transmission-daemon
sudo chown osmc:osmc -R /home/osmc/.config/transmission-daemon
echo "files are successfully restored from folder backup"
echo "starting services..."
sudo service couchpotato start
sudo service sickrage start
sudo service transmission start
echo "services started!"
cd /home/osmc/
