#!bash.sh
#backup user data and addons from kodi (osmc)
echo "creating backup of kodi userdata and addons..."
echo "it may take a few minutes..."
sudo mkdir /home/osmc/kodi_backup
sudo cp -R /home/osmc/.kodi/addons /home/osmc/kodi_backup/addons
sudo cp -R /home/osmc/.kodi/userdata /home/osmc/kodi_backup/userdata
echo "backup created to kodi_backup"
