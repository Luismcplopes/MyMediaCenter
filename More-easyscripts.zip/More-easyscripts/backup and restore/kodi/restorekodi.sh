#!bash.sh
#backup user data and addons from kodi (osmc)
echo "restoring data of kodi userdata and addons from backup..."
echo "it may take a few minutes..."
sudo cp -R /home/osmc/kodi_backup/addons /home/osmc/.kodi/
sudo cp -R /home/osmc/kodi_backup/userdata /home/osmc/.kodi/
sudo chmod -775 -R /home/osmc/.kodi
sudo chmod osmc:osmc -R /home/osmc/.kodi
echo "restored successfully from kodi_backup"
