#!/bin/sh
#backup database and settings for couchpotato, sickrage and transmission
echo "creating backup..."
echo "stopping services..."
sudo service couchpotato stop
sudo service sickrage stop
sudo service transmission stop
cd /home/osmc/
sudo mkdir backup
cd backup
sudo  mkdir settings
cd settings
sudo mkdir sickrage
cd sickrage
echo "copying settings and database files..."
sudo cp /opt/sickrage/config.ini ./
sudo cp /opt/sickrage/sickbeard.db ./
cd ..
sudo mkdir couchpotato
cd couchpotato
sudo cp /home/couchpotato/.couchpotato/*.* ./
cd ..
sudo mkdir transmission
cd transmission
sudo cp /home/osmc/.config/transmission-daemon/*.* ./
echo "files are successfully copied into folder /home/osmc/backup/settings/"
echo "starting services..."
sudo service couchpotato start
sudo service sickrage start
sudo service transmission start
echo "services started!"
cd /home/osmc/
echo "creating backup of kodi userdata and addons..."
echo "it may take a few minutes..."
sudo mkdir /home/osmc/backup/kodi/
sudo cp -R /home/osmc/.kodi/addons/ /home/osmc/backup/kodi/addons
sudo cp -R /home/osmc/.kodi/userdata/ /home/osmc/backup/kodi/userdata
echo "backup created to /home/osmc/backup/kodi"
