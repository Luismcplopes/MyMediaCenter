#!/bin/sh
#rpimonitor installation
sudo apt-get --yes --force-yes update
sudo apt-get --yes --force-yes upgrade
sudo apt-get --yes --force-yes install apt-transport-https ca-certificates
sudo apt-key adv --recv-keys --keyserver keyserver.ubuntu.com 2C0D3C0F
sudo wget http://goo.gl/rsel0F -O /etc/apt/sources.list.d/rpimonitor.list
sudo apt-get --yes --force-yes update
sudo apt-get --yes --force-yes install rpimonitor
sudo /usr/share/rpimonitor/scripts/updatePackagesStatus.pl
