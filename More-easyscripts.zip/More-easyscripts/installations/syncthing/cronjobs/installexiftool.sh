#!/bin/bash
sudo apt-get --yes --force-yes update
sudo apt-get --yes --force-yes upgrade
sudo apt-get --yes --force-yes install exiftool
echo "exiftool installed"
