#!/bin/bash
SRC=/media/3TB/SyncThing/
DEST=/media/3TB/Photos
if [ "$(ls -A $SRC)" ]; then
     cd $SRC
     exiftool -r -d $DEST/%Y/%m/%Y%m%d-%H%M%S.%%e "-FileName<DateTimeOriginal" -ext JPG $SRC
else
echo "No photos found"
fi
