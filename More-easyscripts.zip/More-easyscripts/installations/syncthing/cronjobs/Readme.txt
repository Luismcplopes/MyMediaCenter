Quick Setup Guide for CronTab and ExifTool

1. In osmc appstore instal crontab
2. After installation run ssh.
3. Copy folder into osmc home directory (or copy somewhere else and change path,
4. Before use, you have to change paths in script too, use command sudo nano name-of-the-script.sh)
5. install exiftool with command: sudo apt-get install exiftoolcd
6. Type: crontab -e
7. At the end of file add:

0 2 * * * /bin/sh /home/osmc/cronjobs/sortpics.sh
16 2 * * * /bin/sh /home/osmc/cronjobs/sortvids.sh


More about crontab schedule please guse google :)


0 2 * * * /bin/sh /home/osmc/cronjobs/sortpics.sh
| | | | |   |             |
| | | | |   |             | 
| | | | |   |             |-----> Command/Script to Execute 
| | | | |   |                
| | | | |   |-------------------> where is bash file for runing scripts                    
| | | | |                  
| | | | |-----------------------> Day Of Week (0-7) 0,7 are "Sunday"                   
| | | |                         
| | | |-------------------------> Month of Year (1-12)                 
| | |                           
| | |---------------------------> Day of Month (1-31)                      
| |
| |-----------------------------> Hour (0-23)
|
|-------------------------------> Minute (0-59)

Tip for exiftool: check picture/video information with command:
Example for picture:
exiftool /path-to-your-picture/picture.jpg