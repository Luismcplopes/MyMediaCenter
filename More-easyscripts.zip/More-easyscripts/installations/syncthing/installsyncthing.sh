#!/bin/sh
curl -s https://syncthing.net/release-key.txt | sudo apt-key add -
echo "deb http://apt.syncthing.net/ syncthing release" | sudo tee /etc/apt/sources.list.d/syncthing.list
sudo apt-get update
sudo apt-get install syncthing
sudo echo "#Syncthing systemd service file for OSMC" >> /lib/systemd/system/syncthing.service
sudo echo "#Path should be /lib/systemd/system/syncthing.service" >> /lib/systemd/systetem/syncthing.service
sudo echo " " >> /lib/systemd/systetem/syncthing.service
sudo echo "[Unit]" >> /lib/systemd/systetem/syncthing.service
sudo echo "Description=Syncthing - OSMC" >> /lib/systemd/systetem/syncthing.service
sudo echo "Documentation=http://docs.syncthing.net/" >> /lib/systemd/systetem/syncthing.service
sudo echo "After=network.target" >> /lib/systemd/systetem/syncthing.service
sudo echo "Wants=syncthing-inotify@.service" >> /lib/systemd/systetem/syncthing.service
sudo echo " " >> /lib/systemd/systetem/syncthing.service
sudo echo "[Service]" >> /lib/systemd/systetem/syncthing.service
sudo echo "User=osmc" >> /lib/systemd/systetem/syncthing.service
sudo echo "Nice=7" >> /lib/systemd/systetem/syncthing.service
sudo echo "Environment=STNORESTART=yes" >> /lib/systemd/systetem/syncthing.service
sudo echo "ExecStart=/usr/bin/syncthing -no-browser -logflags=0" >> /lib/systemd/systetem/syncthing.service
sudo echo "Restart=on-failure" >> /lib/systemd/systetem/syncthing.service
sudo echo "SuccessExitStatus=2 3 4" >> /lib/systemd/systetem/syncthing.service
sudo echo "RestartForceExitStatus=3 4" >> /lib/systemd/systetem/syncthing.service
sudo echo " " >> /lib/systemd/systetem/syncthing.service
sudo echo "[Install]" >> /lib/systemd/systetem/syncthing.service
sudo echo "WantedBy=multi-user.target" >> /lib/systemd/systetem/syncthing.service
sudo systemctl enable syncthing.service
sudo systemctl start syncthing.service
sudo service syncthing stop
echo "SyncThing process is stopped, please follow next steps:"
echo " Edit the Syncthing configuration:"
echo "nano /home/osmc/.config/syncthing/config.xml"
echo " "
echo ' - On line 2, change the followingpath="home/osmc/sync/" to the default path you want'
echo "to use. For example in my case, it is my attached USB drive:"
echo 'path="/media/UsbDriveName/'
echo " "
echo " - Also a bit further down the file, change the GUI Listen Address setting from the default 127.0.0.1:8384 to"
echo "0.0.0.0:8384. This is required for remote access of the webUI."
echo "to start service use command: sudo service syncthing start"
echo "use your-rpi-ip:8384"
echo "more info on: http://apt.syncthing.net/"
