#!/bin/sh
echo "uninstalling syncthing"
sudo apt-get remove syncthing
sudo apt-get autoremove
sudo rm /lib/systemd/system/syncthing.service
echo "removed"
