#!/bin/sh
# Installation script of Sickrage and CouchPotato
sudo apt-get --yes --force-yes update && sudo apt-get --yes --force-yes install git
sudo apt-get --yes --force-yes upgrade
sudo apt-get --yes --force-yes install p7zip-full
sudo wget http://sourceforge.net/projects/bananapi/files/unrar_5.2.6-1_armhf.deb
sudo dpkg -i unrar_5.2.6-1_armhf.deb
sudo rm  unrar_5.2.6-1_armhf.deb
sudo useradd couchpotato
sudo usermod -a -G osmc couchpotato
sudo mkdir /home/couchpotato
sudo chown -R couchpotato:couchpotato /home/couchpotato
sudo git clone http://github.com/RuudBurger/CouchPotatoServer /opt/CouchPotatoServer
sudo chown -R couchpotato:couchpotato /opt/CouchPotatoServer
cd /opt/CouchPotatoServer
sudo cp /opt/CouchPotatoServer/init/couchpotato.service /etc/systemd/system/couchpotato.service
cd  /etc/systemd/system/
sudo sed -i 's@/var/lib/CouchPotatoServer/CouchPotato.py@/opt/CouchPotatoServer/CouchPotato.py@g' couchpotato.service
sudo systemctl enable couchpotato.service
sudo systemctl start couchpotato.service
cd
sudo useradd sickrage
sudo usermod -a -G osmc sickrage
sudo git clone https://github.com/SiCKRAGE/SickRage.git /opt/sickrage
sudo cp /opt/sickrage/runscripts/init.systemd /etc/systemd/system/sickrage.service
sudo chown -R sickrage:sickrage /opt/sickrage
sudo chmod +x /opt/sickrage
sudo chmod a-x /etc/systemd/system/sickrage.service
cd /etc/systemd/system
sudo sed -i 's@/usr/bin/python2.7 /opt/sickrage/SickBeard.py -q --daemon --nolaunch --datadir=/opt/sickrage@/opt/sickrage/SickBeard.py -q --daemon --nolaunch --datadir=/opt/sickrage@g' sickrage.service
sudo systemctl enable sickrage.service
sudo systemctl start sickrage.service
sudo service sickrage stop
cd /opt/sickrage/
sudo sed -i 's@web_username = ""@web_username = "osmc"@g' config.ini
sudo sed -i 's@web_password = ""@web_password = "osmc"@g' config.ini
sudo service sickrage start
